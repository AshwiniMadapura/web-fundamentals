# Testing Calculator (Cypress)

This calculator exists to be tested by the trainees with [Cypress](https://www.cypress.io/). In case of them not having their own calculator to test.

## Lesson plan

### Cypress setup | Codealong

1. Create new folder (no need to clone this repo) and follow Cypress [documentation](https://docs.cypress.io/guides/getting-started/installing-cypress#Installing) to set up Cypress

2. Create `cypress:open` script in `package.json`

```json
{
  "scripts": {
    "cypress:open": "cypress open"
  }
}
```

3. Write simple test in `cypress/integration/` folder to show Cypress working

```js
describe("My First Test", () => {
  it("Does not do much!", () => {
    expect(true).to.equal(true);
  });
});

// AND

describe("My First Test", () => {
  it("Does not do much!", () => {
    expect(true).to.equal(false);
  });
});
```

4. Explain Arrange, Act, Assert style of test writing and demonstrate using hosted [calculator](https://nology-tech.github.io/testing-calculator/) as website to test

```js
it("Should check 7+2 equals nine", () => {
  // 1. Arrange
  cy.visit("https://nology-tech.github.io/testing-calculator/");

  // 2. Act
  cy.get(".calculator__number--seven").click();
  cy.get(".calculator__operator--plus").click();
  cy.get(".calculator__number--two").click();
  cy.get(".calculator__operator--equals").click();

  // 3. Assert - How can we improve this?
  //    https://docs.cypress.io/api/commands/should.html#Yields
  cy.get(".calculator__screen").should("contain", "9");
});
```

5. Have trainees look at [this page](https://docs.cypress.io/api/commands/should.html#Yields) of documentation to see how to improve the Assertion

### Cypress Challenge

Using the documentation, test all other aspects of the calculator (minus, times, etc)

What other `.should()` [assertions](https://docs.cypress.io/api/commands/should.html#Yields) could you make?

### Jest setup | Codealong

1. In the same folder, install Jest according to the [documentation](https://jestjs.io/docs/getting-started). Rememeber to install Babel as well in order to use import/export statements

2. Create an empty `script.js` and `script.spec.js`. Show a basic test

```js
// script.js
export const calculateSum = (num1, num2) => {
  return num1 + num2;
};

// script.spec.js
import { calculateSum } from "./script.js";
// 1. Valid Inputs
it("should add 5+2 and be 7", () => {
  // 1.1 Arrange
  let result;

  // 1.2 Act
  result = calculateSum(5, 2);

  // 1.3 Assert
  expect(result).toBe(7);
});
// 2. Invalid Inputs ....?
// 3. Null Inputs ....?
```

3. Write functions for mulitplication, subraction etc.

4. Explain testing for good, bad and null inputs. Testing goes a lot deeper!

### Jest Challenge 1

Write tests for [this](https://github.com/nology-tech/jest-unit-testing/blob/master/scripts/darts/darts.js) darts function

```js
// Write a function that returns the earned points (single throw)
// function that takes 2 parameter to work out how close a "dart" is to the centre of the board... contrived example as the player only throws one dart

// darts lands....
// outside the target, player earns no points (0 points).
// outer circle of the target, 1 point.
// middle circle of the target, 5 points.
// inner circle of the target, 10 points.

// write the function WITHOUT the initial if statement, then show failing test when we add arguments that aren't numbers

// Function without IF statement !! TEST THIS FIRST !!
export const findScore = (x, y) => {
  // euclidean distance (using Pythagorean theorem)
  const distanceToDart = Math.sqrt(x * x + y * y);

  // distance to target
  if (distanceToDart > 10) return 0;
  if (distanceToDart > 5) return 1;
  if (distanceToDart > 1) return 5;
  return 10;
};

// Function with IF statement !! THEN MOVE TO THIS !!
export const findScore = (x, y) => {
  if (Number.isNaN(Number(x)) || Number.isNaN(Number(y))) return null;

  // euclidean distance (using Pythagorean theorem)
  const distanceToDart = Math.sqrt(x * x + y * y);

  // distance to target
  if (distanceToDart > 10) return 0;
  if (distanceToDart > 5) return 1;
  if (distanceToDart > 1) return 5;
  return 10;
};
```

OPTIONAL: Write tests for [this](https://github.com/nology-tech/jest-unit-testing/blob/master/scripts/triangle/triangle.js) triangle class

```js
// NOTES
// COACH TO DECIDE WHETHER TO ACTUALLY CODE THIS OR JUST EXPLAIN IT TO THEM
// Beast mode solution to this problem is using a Set();
// Done using getters in the triangle class, to change this remove the 'get' from infront of the method and add a set of () to invoke inside the test suite

// TASK
// Determine if a triangle is equilateral, isosceles, or scalene.

// For a shape to be a triangle at all, all sides have to be of length > 0, and
// the sum of the lengths of any two sides must be greater than or equal to the
// length of the third side.

export class Triangle {
  // constructor is a special method that runs when an instance of the class is being built...
  constructor(...sides) {
    // binding to 'this' instance of the class
    this.sides = sides;
  }

  // validation method to be called inside other 3 methods to ensure valid user inputs
  get isValid() {
    const [s1, s2, s3] = this.sides;
    const sidesArePositive = s1 > 0 && s2 > 0 && s3 > 0;
    const validatesTriangleInequality = s1 + s2 >= s3 && s1 + s3 >= s2 && s2 + s3 >= s1;
    return sidesArePositive && validatesTriangleInequality;
  }

  // a triangle with 3 sides of the same length
  get isEquilateral() {
    if (!this.isValid) {
      return false;
    }
    const [s1, s2, s3] = this.sides;
    return s1 === s2 && s2 === s3 && s1 === s3;
  }

  // a triangle that has two sides of equal length
  get isIsosceles() {
    if (!this.isValid) {
      return false;
    }
    const [s1, s2, s3] = this.sides;
    return s1 === s2 || s1 === s3 || s2 === s3;
  }

  // a triangle in which all three sides have different lengths
  get isScalene() {
    if (!this.isValid) {
      return false;
    }
    return !this.isIsosceles;
  }
}
```

### Jest Challenge 2

Using TDD - Write code which translates "hello" into French / any other language `hello => bonjour || hello => guten tag`

Stub the functions with students, then let them loose.

They can then implement valid/invalid/null test cases

```js
// translator.js
// Stub function. Tests will fail initially
export const translate = (englishWord) => {};

// translator.spec.js
import { translate } from "./translator.js";

// Potential tests outlined below
// 1. Valid Inputs
it("Should translate hello to kia ora", () => {
  // Arrange
  const result = translate("hello");

  // Assert
  expect(result).toBe("kia ora");
});

// 2. Invalid Inputs
it("Should translate asdfasdf to unavailable", () => {
  // ...... <--- test your function with an invalid input
});

// 3. Null Inputs
it("Should translate undefined to unavailable", () => {
  // ...... <---- test your function with an undefined input
});
```

Review Challenge - Talk/Discuss different approaches as a group

## Using this repository

Install dependencies with `npm install`

### scripts

All scripts preceeded with `npm run`

|       Script       | Purpose                                                                                                                                          |
| :----------------: | ------------------------------------------------------------------------------------------------------------------------------------------------ |
|    compile:scss    | Turns scss into css and places it in `css` folder                                                                                                |
| compile:scss-watch | Same as previous, but compiles files on save                                                                                                     |
|        dist        | Creates a `dist` folder to place website into for hosting purposes                                                                               |
|       delete       | Deletes the `dist` folder                                                                                                                        |
|        copy        | Copies files necessary to make the website work from the `src` folder to the `dist` folder                                                       |
|       build        | Runs the delete, dist, compile:scss and copy scripts sequentially. Essentially creating a version of the website to be used for hosting purposes |
|       deploy       | Runs the build script followed by using the gh-pages npm package to host the `dist` folder via GitHub pages                                      |
